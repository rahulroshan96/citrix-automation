#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License")
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

from nitro.resource.base.base_resource import base_resource
from nitro.resource.base.base_resource import base_response
from nitro.service.options import options
from nitro.exception.nitro_exception import nitro_exception

from nitro.util.nitro_util import nitro_util

class dnszone(base_resource) :
    """Configuration for DNS zone resource."""
    def __init__(self) :
        self._zonename = ""
        self._proxymode = ""
        self._dnssecoffload = ""
        self._nsec = ""
        self._keyname = []
        self._type = ""
        self._flags = 0
        self.___count = 0

    @property
    def zonename(self) :
        """Name of the zone to create.<br/>Minimum length =  1."""
        try :
            return self._zonename
        except Exception as e:
            raise e

    @zonename.setter
    def zonename(self, zonename) :
        """Name of the zone to create.<br/>Minimum length =  1

        :param zonename: 

        """
        try :
            self._zonename = zonename
        except Exception as e:
            raise e

    @property
    def proxymode(self) :
        """Deploy the zone in proxy mode. Enable in the following scenarios:
        * The load balanced DNS servers are authoritative for the zone and all resource records that are part of the zone.
        * The load balanced DNS servers are authoritative for the zone, but the NetScaler appliance owns a subset of the resource records that belong to the zone (partial zone ownership configuration). Typically seen in global server load balancing (GSLB) configurations, in which the appliance responds authoritatively to queries for GSLB domain names but forwards queries for other domain names in the zone to the load balanced servers.
        In either scenario, do not create the zone's Start of Authority (SOA) and name server (NS) resource records on the appliance.
        Disable if the appliance is authoritative for the zone, but make sure that you have created the SOA and NS records on the appliance before you create the zone.<br/>Default value: ENABLED<br/>Possible values = YES, NO.


        """
        try :
            return self._proxymode
        except Exception as e:
            raise e

    @proxymode.setter
    def proxymode(self, proxymode) :
        """Deploy the zone in proxy mode. Enable in the following scenarios:
        * The load balanced DNS servers are authoritative for the zone and all resource records that are part of the zone.
        * The load balanced DNS servers are authoritative for the zone, but the NetScaler appliance owns a subset of the resource records that belong to the zone (partial zone ownership configuration). Typically seen in global server load balancing (GSLB) configurations, in which the appliance responds authoritatively to queries for GSLB domain names but forwards queries for other domain names in the zone to the load balanced servers.
        In either scenario, do not create the zone's Start of Authority (SOA) and name server (NS) resource records on the appliance.
        Disable if the appliance is authoritative for the zone, but make sure that you have created the SOA and NS records on the appliance before you create the zone.<br/>Default value: ENABLED<br/>Possible values = YES, NO

        :param proxymode: 

        """
        try :
            self._proxymode = proxymode
        except Exception as e:
            raise e

    @property
    def dnssecoffload(self) :
        """Enable dnssec offload for this zone.<br/>Default value: DISABLED<br/>Possible values = ENABLED, DISABLED."""
        try :
            return self._dnssecoffload
        except Exception as e:
            raise e

    @dnssecoffload.setter
    def dnssecoffload(self, dnssecoffload) :
        """Enable dnssec offload for this zone.<br/>Default value: DISABLED<br/>Possible values = ENABLED, DISABLED

        :param dnssecoffload: 

        """
        try :
            self._dnssecoffload = dnssecoffload
        except Exception as e:
            raise e

    @property
    def nsec(self) :
        """Enable nsec generation for dnssec offload.<br/>Default value: DISABLED<br/>Possible values = ENABLED, DISABLED."""
        try :
            return self._nsec
        except Exception as e:
            raise e

    @nsec.setter
    def nsec(self, nsec) :
        """Enable nsec generation for dnssec offload.<br/>Default value: DISABLED<br/>Possible values = ENABLED, DISABLED

        :param nsec: 

        """
        try :
            self._nsec = nsec
        except Exception as e:
            raise e

    @property
    def keyname(self) :
        """Name of the public/private DNS key pair with which to sign the zone. You can sign a zone with up to four keys.<br/>Minimum length =  1."""
        try :
            return self._keyname
        except Exception as e:
            raise e

    @keyname.setter
    def keyname(self, keyname) :
        """Name of the public/private DNS key pair with which to sign the zone. You can sign a zone with up to four keys.<br/>Minimum length =  1

        :param keyname: 

        """
        try :
            self._keyname = keyname
        except Exception as e:
            raise e

    @property
    def type(self) :
        """Type of zone to display. Mutually exclusive with the DNS Zone (zoneName) parameter. Available settings function as follows:
        * ADNS - Display all the zones for which the NetScaler appliance is authoritative.
        * PROXY - Display all the zones for which the NetScaler appliance is functioning as a proxy server.
        * ALL - Display all the zones configured on the appliance.<br/>Possible values = ALL, ADNS, PROXY.


        """
        try :
            return self._type
        except Exception as e:
            raise e

    @type.setter
    def type(self, type) :
        """Type of zone to display. Mutually exclusive with the DNS Zone (zoneName) parameter. Available settings function as follows:
        * ADNS - Display all the zones for which the NetScaler appliance is authoritative.
        * PROXY - Display all the zones for which the NetScaler appliance is functioning as a proxy server.
        * ALL - Display all the zones configured on the appliance.<br/>Possible values = ALL, ADNS, PROXY

        :param type: 

        """
        try :
            self._type = type
        except Exception as e:
            raise e

    @property
    def flags(self) :
        """Flags controlling display."""
        try :
            return self._flags
        except Exception as e:
            raise e

    def _get_nitro_response(self, service, response) :
        """converts nitro response into object and returns the object array in case of get request.

        :param service: 
        :param response: 

        """
        try :
            result = service.payload_formatter.string_to_resource(dnszone_response, response, self.__class__.__name__)
            if(result.errorcode != 0) :
                if (result.errorcode == 444) :
                    service.clear_session(self)
                if result.severity :
                    if (result.severity == "ERROR") :
                        raise nitro_exception(result.errorcode, str(result.message), str(result.severity))
                else :
                    raise nitro_exception(result.errorcode, str(result.message), str(result.severity))
            return result.dnszone
        except Exception as e :
            raise e

    def _get_object_name(self) :
        """Returns the value of object identifier argument"""
        try :
            if self.zonename is not None :
                return str(self.zonename)
            return None
        except Exception as e :
            raise e



    @classmethod
    def add(cls, client, resource) :
        """Use this API to add dnszone.

        :param client: 
        :param resource: 

        """
        try :
            if type(resource) is not list :
                addresource = dnszone()
                addresource.zonename = resource.zonename
                addresource.proxymode = resource.proxymode
                addresource.dnssecoffload = resource.dnssecoffload
                addresource.nsec = resource.nsec
                return addresource.add_resource(client)
            else :
                if (resource and len(resource) > 0) :
                    addresources = [ dnszone() for _ in range(len(resource))]
                    for i in range(len(resource)) :
                        addresources[i].zonename = resource[i].zonename
                        addresources[i].proxymode = resource[i].proxymode
                        addresources[i].dnssecoffload = resource[i].dnssecoffload
                        addresources[i].nsec = resource[i].nsec
                result = cls.add_bulk_request(client, addresources)
            return result
        except Exception as e :
            raise e

    @classmethod
    def update(cls, client, resource) :
        """Use this API to update dnszone.

        :param client: 
        :param resource: 

        """
        try :
            if type(resource) is not list :
                updateresource = dnszone()
                updateresource.zonename = resource.zonename
                updateresource.proxymode = resource.proxymode
                updateresource.dnssecoffload = resource.dnssecoffload
                updateresource.nsec = resource.nsec
                return updateresource.update_resource(client)
            else :
                if (resource and len(resource) > 0) :
                    updateresources = [ dnszone() for _ in range(len(resource))]
                    for i in range(len(resource)) :
                        updateresources[i].zonename = resource[i].zonename
                        updateresources[i].proxymode = resource[i].proxymode
                        updateresources[i].dnssecoffload = resource[i].dnssecoffload
                        updateresources[i].nsec = resource[i].nsec
                result = cls.update_bulk_request(client, updateresources)
            return result
        except Exception as e :
            raise e

    @classmethod
    def unset(cls, client, resource, args) :
        """Use this API to unset the properties of dnszone resource.
        Properties that need to be unset are specified in args array.

        :param client: 
        :param resource: 
        :param args: 

        """
        try :
            if type(resource) is not list :
                unsetresource = dnszone()
                if type(resource) !=  type(unsetresource):
                    unsetresource.zonename = resource
                else :
                    unsetresource.zonename = resource.zonename
                return unsetresource.unset_resource(client, args)
            else :
                if type(resource[0]) != cls :
                    if (resource and len(resource) > 0) :
                        unsetresources = [ dnszone() for _ in range(len(resource))]
                        for i in range(len(resource)) :
                            unsetresources[i].zonename = resource[i]
                else :
                    if (resource and len(resource) > 0) :
                        unsetresources = [ dnszone() for _ in range(len(resource))]
                        for i in range(len(resource)) :
                            unsetresources[i].zonename = resource[i].zonename
                result = cls.unset_bulk_request(client, unsetresources, args)
            return result
        except Exception as e :
            raise e

    @classmethod
    def delete(cls, client, resource) :
        """Use this API to delete dnszone.

        :param client: 
        :param resource: 

        """
        try :
            if type(resource) is not list :
                deleteresource = dnszone()
                if type(resource) !=  type(deleteresource):
                    deleteresource.zonename = resource
                else :
                    deleteresource.zonename = resource.zonename
                return deleteresource.delete_resource(client)
            else :
                if type(resource[0]) != cls :
                    if (resource and len(resource) > 0) :
                        deleteresources = [ dnszone() for _ in range(len(resource))]
                        for i in range(len(resource)) :
                            deleteresources[i].zonename = resource[i]
                else :
                    if (resource and len(resource) > 0) :
                        deleteresources = [ dnszone() for _ in range(len(resource))]
                        for i in range(len(resource)) :
                            deleteresources[i].zonename = resource[i].zonename
                result = cls.delete_bulk_request(client, deleteresources)
            return result
        except Exception as e :
            raise e

    @classmethod
    def sign(cls, client, resource) :
        """Use this API to sign dnszone.

        :param client: 
        :param resource: 

        """
        try :
            if type(resource) is not list :
                signresource = dnszone()
                signresource.zonename = resource.zonename
                signresource.keyname = resource.keyname
                return signresource.perform_operation(client,"sign")
            else :
                if (resource and len(resource) > 0) :
                    signresources = [ dnszone() for _ in range(len(resource))]
                    for i in range(len(resource)) :
                        signresources[i].zonename = resource[i].zonename
                        signresources[i].keyname = resource[i].keyname
                result = cls.perform_operation_bulk_request(client, signresources,"sign")
            return result
        except Exception as e :
            raise e

    @classmethod
    def unsign(cls, client, resource) :
        """Use this API to unsign dnszone.

        :param client: 
        :param resource: 

        """
        try :
            if type(resource) is not list :
                unsignresource = dnszone()
                unsignresource.zonename = resource.zonename
                unsignresource.keyname = resource.keyname
                return unsignresource.perform_operation(client,"unsign")
            else :
                if (resource and len(resource) > 0) :
                    unsignresources = [ dnszone() for _ in range(len(resource))]
                    for i in range(len(resource)) :
                        unsignresources[i].zonename = resource[i].zonename
                        unsignresources[i].keyname = resource[i].keyname
                result = cls.perform_operation_bulk_request(client, unsignresources,"unsign")
            return result
        except Exception as e :
            raise e

    @classmethod
    def get(cls, client, name="", option_="") :
        """Use this API to fetch all the dnszone resources that are configured on netscaler.

        :param client: 
        :param name:  (Default value = "")
        :param option_:  (Default value = "")

        """
        try :
            if not name :
                obj = dnszone()
                response = obj.get_resources(client, option_)
            else :
                if type(name) != cls :
                    if type(name) is not list :
                        obj = dnszone()
                        obj.zonename = name
                        response = obj.get_resource(client, option_)
                    else :
                        if name and len(name) > 0 :
                            response = [dnszone() for _ in range(len(name))]
                            obj = [dnszone() for _ in range(len(name))]
                            for i in range(len(name)) :
                                obj[i] = dnszone()
                                obj[i].zonename = name[i]
                                response[i] = obj[i].get_resource(client, option_)
            return response
        except Exception as e :
            raise e


    @classmethod
    def get_args(cls, client, args) :
        """Use this API to fetch all the dnszone resources that are configured on netscaler.
            # This uses dnszone_args which is a way to provide additional arguments while fetching the resources.

        :param client: 
        :param args: 

        """
        try :
            obj = dnszone()
            option_ = options()
            option_.args = nitro_util.object_to_string_withoutquotes(args)
            response = obj.get_resources(client, option_)
            return response
        except Exception as e :
            raise e


    @classmethod
    def get_filtered(cls, client, filter_) :
        """Use this API to fetch filtered set of dnszone resources.
        filter string should be in JSON format.eg: "port:80,servicetype:HTTP".

        :param client: 
        :param filter_: 

        """
        try :
            obj = dnszone()
            option_ = options()
            option_.filter = filter_
            response = obj.getfiltered(client, option_)
            return response
        except Exception as e :
            raise e


    @classmethod
    def count(cls, client) :
        """Use this API to count the dnszone resources configured on NetScaler.

        :param client: 

        """
        try :
            obj = dnszone()
            option_ = options()
            option_.count = True
            response = obj.get_resources(client, option_)
            if response :
                return response[0].__dict__['___count']
            return 0
        except Exception as e :
            raise e

    @classmethod
    def count_filtered(cls, client, filter_) :
        """Use this API to count filtered the set of dnszone resources.
        Filter string should be in JSON format.eg: "port:80,servicetype:HTTP".

        :param client: 
        :param filter_: 

        """
        try :
            obj = dnszone()
            option_ = options()
            option_.count = True
            option_.filter = filter_
            response = obj.getfiltered(client, option_)
            if response :
                return response[0].__dict__['___count']
            return 0
        except Exception as e :
            raise e


    class Type:
        """ """
        ALL = "ALL"
        ADNS = "ADNS"
        PROXY = "PROXY"

    class Proxymode:
        """ """
        YES = "YES"
        NO = "NO"

    class Nsec:
        """ """
        ENABLED = "ENABLED"
        DISABLED = "DISABLED"

    class Dnssecoffload:
        """ """
        ENABLED = "ENABLED"
        DISABLED = "DISABLED"

class dnszone_response(base_response) :
    """ """
    def __init__(self, length=1) :
        self.dnszone = []
        self.errorcode = 0
        self.message = ""
        self.severity = ""
        self.sessionid = ""
        self.dnszone = [dnszone() for _ in range(length)]

